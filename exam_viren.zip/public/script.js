async function fetcher(str) {
  console.log(str);
  let temp = await fetch(str);
  let ans = await temp.json();
  let s = ` <div class="d-flex flex-row align-items-center question-title">
                <h3 class="text-danger">Q.</h3>
                <h5 class="mt-1 ml-2">${ans[0].question_text}</h5>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_a}">
                  <span>${ans[0].option_a}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_b}">
                  <span>${ans[0].option_b}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_c}">
                  <span>${ans[0].option_c}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_d}">
                  <span>${ans[0].option_d}</span>
                </label>
              </div>`;
  que.innerHTML = s;
  let qn = `<span class= "que-no">${ans[0].question_id}</span>`;
  que_no.innerHTML = qn;
  let btn = `<div
    class="row justify-content-around align-items-center"
    id="row"
  >
    <input
      type="button"
      value="PREV"
      onclick="previous_btn('${ans[0].question_id}')"
      class="border border-info rounded p-1 bg-white text-info font-weight-bold col-2"
      id="prev"
    />

    <input
      type="button"
      value="NEXT"
      onclick="next_btn('${ans[0].question_id}')"
      class="btn btn-primary btn-success col-2 font-weight-bold"
      id="next"
    />
  </div>`;
  btns.innerHTML = btn;
}

async function next_btn(id) {
  // console.log(id);
  let temp1 = await fetch(`/next?id=${id}`);
  let tmp = await temp1.json();
  // console.log(tmp[0].question_id);
  await fetcher(
    `/paging/?question_no=${tmp[0].question_id}&category_id=${tmp[0].category_id}`
  );
  let s = `<div
    class="row justify-content-around align-items-center"
    id="row"
  >
    <input
      type="button"
      value="PREV"
      onclick="previous_btn('${tmp[0].question_id}')"
      class="border border-info rounded p-1 bg-white text-info font-weight-bold col-2"
      id="prev"
    />

    <input
      type="button"
      value="NEXT"
      onclick="next_btn('${tmp[0].question_id}')"
      class="btn btn-primary btn-success col-2 font-weight-bold"
      id="next"
    />
  </div>`;
  btns.innerHTML = s;
}

async function previous_btn(id) {
  console.log(id);
  let temp = await fetch(`http://localhost:4321/prev?id=${id}`);
  let tmp = await temp.json();
  await fetcher(
    `/paging/?question_no=${tmp[0].question_id}&category_id=${tmp[0].category_id}`
  );
  let s = `<div
    class="row justify-content-around align-items-center"
    id="row"
  >
    <input
      type="button"
      value="PREV"
      onclick="previous_btn('${tmp[0].question_id}')"
      class="border border-info rounded p-1 bg-white text-info font-weight-bold col-2"
      id="prev"
    />

    <input
      type="button"
      value="NEXT"
      onclick="next_btn('${tmp[0].question_id}')"
      class="btn btn-primary btn-success col-2 font-weight-bold"
      id="next"
    />
  </div>`;
  btns.innerHTML = s;
}

async function category_changer(e) {
  // console.log(e.id);
  let temp = await fetch(`/category?id=${e.id}`);
  let ans = await temp.json();
  console.log(ans);
  let s = ` <div class="d-flex flex-row align-items-center question-title">
                <h3 class="text-danger">Q.</h3>
                <h5 class="mt-1 ml-2">${ans[0].question_text}</h5>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_a}">
                  <span>${ans[0].option_a}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_b}">
                  <span>${ans[0].option_b}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_c}">
                  <span>${ans[0].option_c}</span>
                </label>
              </div>
              <div class="ans ml-2">
                <label class="radio">
                  <input type="radio" name="q-${ans[0].question_id}" value="${ans[0].option_d}">
                  <span>${ans[0].option_d}</span>
                </label>
              </div>`;
  que.innerHTML = s;
  let qn = `<span class= "que-no">${ans[0].question_id}</span>`;
  que_no.innerHTML = qn;
  let btn = `<div
    class="row justify-content-around align-items-center"
    id="row"
  >
    <input
      type="button"
      value="PREV ${ans[0].question_id}"
      onclick="previous_btn('${ans[0].question_id}')"
      class="border border-info rounded p-1 bg-white text-info font-weight-bold col-2"
      id="prev"
    />

    <input
      type="button"
      value="NEXT ${ans[0].question_id}"
      onclick="next_btn('${ans[0].question_id}')"
      class="btn btn-primary btn-success col-2 font-weight-bold"
      id="next"
    />
  </div>`;
  btns.innerHTML = btn;
}
