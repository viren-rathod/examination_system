# examination_system
An online student examination system using Node JS and MySQL.
